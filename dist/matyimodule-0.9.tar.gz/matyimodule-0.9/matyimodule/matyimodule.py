from markdown import markdown
def mark():
    '''
    Kiírja a kijelződre hogy ki is csinálta ezt a csomagot.
    '''
    return markdown(u'Matyi vagyok *cső*')